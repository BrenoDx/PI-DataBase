DROP USER 'user_gerente'@'localhost';

CREATE USER 'user_gerente' IDENTIFIED BY '2540';
GRANT ALL PRIVILEGES ON loja_db.* TO 'user_gerente'@'localhost';

CREATE USER 'user_atendente'@'localhost' IDENTIFIED BY '6431';
CREATE ROLE 'lj_funcionario';
SET DEFAULT ROLE 'lj_fucnionario' TO 'user_atendente'@'localhost';

GRANT SELECT, INSERT, UPDATE, DELETE ON fg_db.venda TO 'lj_funcionario';
GRANT SELECT, INSERT, UPDATE, DELETE ON fg_db.venda_produto TO 'lj_funcionario';
GRANT SELECT, INSERT, UPDATE, DELETE ON fg_db.orcamento TO 'lj_funcionario';
GRANT SELECT, INSERT, UPDATE, DELETE ON fg_db.orcamento_produto TO 'lj_funcionario';
GRANT SELECT, INSERT, UPDATE, DELETE ON fg_db.cliente TO 'lj_funcionario';
GRANT SELECT ON fg_db.estoque TO 'lj_funcionario';
GRANT SELECT ON fg_db.produto TO 'lj_funcionario';


