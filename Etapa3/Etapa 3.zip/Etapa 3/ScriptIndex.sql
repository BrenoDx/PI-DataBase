CREATE INDEX idx_fabricante_categoria ON produto (fabricante, categoria) 
SHOW INDEX FROM produto;

SELECT * 
FROM produto
WHERE fabricante = 'ASUS' AND categoria = 'PLACA MÃE'
ORDER BY fabricante, categoria;
