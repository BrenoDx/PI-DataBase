DELIMITER //
CREATE PROCEDURE remersa_estoque (produto_id INT, qntd_remersa INT)
BEGIN 
	UPDATE estoque
	SET quantidade = quantidade + qntd_remersa
	WHERE id = produto_id;
END//
DELIMITER ;

----- Primeiro coloquei dois parâmentros onde receberemos id do produto e a quantidade do fornecedor 
----- Em seguida somamos a quantidade que já tem no estoque com a nova remersa
----- A chamada do PROCEDURE, escolhi o produto 1 a placa de video onde tem 7 no estoque e agora chegou mais 7 novas placas RX 6600
CALL remersa_estoque(1, 7)
