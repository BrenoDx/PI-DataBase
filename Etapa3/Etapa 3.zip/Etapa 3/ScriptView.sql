----- Uma view para obter informações dos produtos mais vendidos e situação do estoque
CREATE VIEW relat_vend_mais_vendidos AS
SELECT e.nomeProduto, e.quantidade AS estoque, p.fabricante, p.categoria, SUM(vp.qntdProduto) AS mais_vendidos
FROM estoque e
JOIN produto p ON e.id = p.estoque_id
JOIN venda_produto vp ON p.id =vp.produto_id
GROUP BY e.nomeProduto, estoque, p.fabricante, p.categoria
ORDER BY mais_vendidos DESC

SELECT * FROM relat_vend_mais_vendidos
